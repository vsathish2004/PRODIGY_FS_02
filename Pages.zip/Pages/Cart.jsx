import React from 'react'
import { CartItems } from '../Component/Cartitems/CartItems'

export const Cart = () => {
  return (
    <div>
      <CartItems/>
    </div>
  )
}
